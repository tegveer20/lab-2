﻿
type Coach = { Name: string; FormerPlayer: bool }
type Stats = { Wins: int; Losses: int }
type Team = { Name: string; Coach: Coach; Stats: Stats }


let sportsTeams = [
    { Name = "Cleveland Cavaliers"; Coach = { Name = "Kenny Atkinson"; FormerPlayer = true }; Stats = { Wins = 2955; Losses = 1800 } }
    { Name = "Huston Rockets"; Coach = { Name = "Ime Udoka"; FormerPlayer = false }; Stats = { Wins = 2510; Losses = 2010 } }
    { Name = "Indiana Pacers"; Coach = { Name = "Rick Carlisle"; FormerPlayer = true }; Stats = { Wins = 1805; Losses = 1680 } }
    { Name = "Miami Heat"; Coach = { Name = "Erick Spoelstra"; FormerPlayer = true }; Stats = { Wins = 1350; Losses = 1305 } }
    { Name = "LA Clippers"; Coach = { Name = "Tyronn Lue"; FormerPlayer = false }; Stats = { Wins = 1250; Losses = 1300 } }
]


let winningTeams = 
    sportsTeams
    |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)


let calculateSuccessRates = 
    winningTeams
    |> List.map (fun team -> 
        let totalWins = float team.Stats.Wins
        let totalLosses = float team.Stats.Losses
        let winPercentage = (totalWins / (totalWins + totalLosses)) * 100.0
        (team.Name, winPercentage)
    )


calculateSuccessRates
|> List.iter (fun (name, percentage) -> 
    printfn "Team: %s, Success Percentage: %.2f%%" name percentage
)



type FoodType =
    | Italian
    | Mexican

type MovieExperience =
    | Standard
    | IMAX3D
    | PremiumSeats
    | StandardWithSnacks
    | IMAX3DWithSnacks
    | PremiumWithSnacks

type DateActivity =
    | CardGame
    | Relax
    | WatchMovie of MovieExperience
    | DineOut of FoodType
    | RoadTrip of int * float


let estimateCost (activity: DateActivity) =
    match activity with
    | CardGame -> 0.0 
    | Relax -> 0.0 
    | WatchMovie movie -> 
        match movie with
        | Standard -> 10.0
        | IMAX3D -> 15.0
        | PremiumSeats -> 25.0
        | StandardWithSnacks -> 10.0 + 6.0
        | IMAX3DWithSnacks -> 15.0 + 6.0
        | PremiumWithSnacks -> 25.0 + 6.0
    | DineOut cuisine ->
        match cuisine with
        | Italian -> 80.0
        | Mexican -> 60.0
    | RoadTrip (distance, fuelRate) -> float distance * fuelRate


let dateNightPlans = [
    CardGame
    Relax
    WatchMovie Standard
    WatchMovie IMAX3DWithSnacks
    DineOut Italian
    RoadTrip (150, 1.8)
]


dateNightPlans
|> List.iter (fun activity ->
    let cost = estimateCost activity
    printfn "Activity: %A | Cost: %.2f CAD" activity cost
)